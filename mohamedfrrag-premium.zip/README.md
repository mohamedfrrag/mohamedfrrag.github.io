# Mohamed Frrag · Portfolio Website

Static bilingual (Arabic/English) website for GitHub Pages. No paid hosting needed.

## Upload
Upload **index.html**, **portfolio.html**, **assets/**, and optionally **Mohamed_Frrag_CV.docx** to the root of `mohamedfrrag.github.io` repository. Keep the existing `Settings → Pages → main / (root)` configuration. Do not upload the ZIP directly.

## Pages
- index.html: homepage with services, working process, and contact.
- portfolio.html: career experience, professional skills, CV, and truthful project placeholder.

## Customize
- All Arabic & English copy is in `assets/app.js`.
- Colors, animation and responsive layout are in `assets/style.css`.
- Logo is `assets/logo.svg` (MF monogram, no portraits).
- WhatsApp links are set to `+965 9471 5049` (`https://wa.me/96594715049`).
- CV file contains contact information; consider uploading a redacted public version if desired.
- Actual projects/screenshots can be added to portfolio.html later.

Motion respects `prefers-reduced-motion`. Theme/language are saved locally in the browser. No stock photos or fake client logos included.
